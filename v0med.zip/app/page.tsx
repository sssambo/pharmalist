"use client"

import AddMedicineForm from "../frontend/src/components/AddMedicineForm"

export default function SyntheticV0PageForDeployment() {
  return <AddMedicineForm />
}